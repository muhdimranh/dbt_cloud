select * from {{ source("bronze_table", "bronze_cost_center_logs") }}
